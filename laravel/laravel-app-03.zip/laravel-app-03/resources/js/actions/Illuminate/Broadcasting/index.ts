import BroadcastController from './BroadcastController'
const Broadcasting = {
    BroadcastController,
}

export default Broadcasting