import Controllers from './Controllers'
const Http = {
    Controllers,
}

export default Http