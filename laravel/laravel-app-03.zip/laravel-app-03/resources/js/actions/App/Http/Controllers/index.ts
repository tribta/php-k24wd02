import Settings from './Settings'
import Auth from './Auth'
import ConversationController from './ConversationController'
const Controllers = {
    Settings,
Auth,
ConversationController,
}

export default Controllers