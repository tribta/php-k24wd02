import Http from './Http'
const App = {
    Http,
}

export default App