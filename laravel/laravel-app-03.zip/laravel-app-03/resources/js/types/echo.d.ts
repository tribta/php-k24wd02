export {};
declare global {
    interface window {
        Echo: any;
        Pusher: any;
    }
}
